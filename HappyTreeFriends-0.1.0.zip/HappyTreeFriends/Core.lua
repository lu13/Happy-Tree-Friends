local ADDON_NAME, HTF = ...

HTF.ADDON_NAME = ADDON_NAME
HTF.VERSION = "0.1.0"
HTF.debugLog = {}

HTF.defaults = {
	autoRepair = false,
	autoSellJunk = false,
	showStats = true,
	showNotifications = true,
	debug = false,
}

local function mergeDefaults(target, defaults)
	for key, defaultValue in pairs(defaults) do
		if type(defaultValue) == "table" then
			if type(target[key]) ~= "table" then
				target[key] = {}
			end
			mergeDefaults(target[key], defaultValue)
		elseif target[key] == nil then
			target[key] = defaultValue
		end
	end
end

function HTF:InitializeDatabase()
	if type(HappyTreeFriendsDB) ~= "table" then
		HappyTreeFriendsDB = {}
	end

	mergeDefaults(HappyTreeFriendsDB, self.defaults)
	self.db = HappyTreeFriendsDB
end

function HTF:GetSetting(key)
	return self.db and self.db[key]
end

function HTF:SetSetting(key, value)
	if not self.db then
		return
	end

	self.db[key] = value
	if self.Options and self.Options.Refresh then
		self.Options:Refresh()
	end
end

function HTF:IsSecretValue(value)
	return type(issecretvalue) == "function" and issecretvalue(value) or false
end

function HTF:IsSafeNumber(value)
	if self:IsSecretValue(value) then
		return false
	end

	return type(value) == "number"
end

function HTF:Notify(message)
	if DEFAULT_CHAT_FRAME then
		DEFAULT_CHAT_FRAME:AddMessage("|cff6ee7b7[HTF]|r " .. message)
	end
end

function HTF:Debug(message)
	if not self.db or not self.db.debug then
		return
	end

	local timestamp = date and date("%H:%M:%S") or "--:--:--"
	local line = string.format("[%s] %s", timestamp, tostring(message))
	table.insert(self.debugLog, line)
	if #self.debugLog > 80 then
		table.remove(self.debugLog, 1)
	end

	if DEFAULT_CHAT_FRAME then
		DEFAULT_CHAT_FRAME:AddMessage("|cff8db7ff[HTF Debug]|r " .. line)
	end

	if self.Options and self.Options.RefreshDebugLog then
		self.Options:RefreshDebugLog()
	end
end

function HTF:Debugf(formatText, ...)
	if not self.db or not self.db.debug then
		return
	end

	local ok, message = pcall(string.format, formatText, ...)
	self:Debug(ok and message or formatText)
end

function HTF:FormatMoney(copper)
	if not self:IsSafeNumber(copper) then
		return "—"
	end

	local gold = math.floor(copper / 10000)
	local silver = math.floor((copper % 10000) / 100)
	local remainingCopper = copper % 100
	local parts = {}

	if gold > 0 then
		table.insert(parts, string.format("%d|cffffd700金|r", gold))
	end
	if silver > 0 or gold > 0 then
		table.insert(parts, string.format("%d|cffc7c7cf银|r", silver))
	end
	table.insert(parts, string.format("%d|cffeda55f铜|r", remainingCopper))

	return table.concat(parts, " ")
end

local function trim(value)
	return (value or ""):match("^%s*(.-)%s*$")
end

function HTF:OpenOptions(page)
	if self.Options and self.Options.Open then
		self.Options:Open(page)
	end
end

function HTF:HandleSlashCommand(input)
	local command = string.lower(trim(input))

	if command == "debug" then
		local enabled = not self:GetSetting("debug")
		self:SetSetting("debug", enabled)
		self:Notify(enabled and "调试模式已开启。" or "调试模式已关闭。")
		if enabled then
			self:Debug("调试模式已开启。")
		end
		return
	end

	if command == "stats" or command == "属性" then
		self:OpenOptions("stats")
		return
	end

	if command == "merchant" or command == "商人" then
		self:OpenOptions("merchant")
		return
	end

	if command == "help" or command == "帮助" then
		self:Notify("/htf — 设置；/htf stats — 角色属性；/htf debug — 开关调试模式。")
		return
	end

	self:OpenOptions("overview")
end

function HTF:RegisterSlashCommands()
	SLASH_HAPPYTREEFRIENDS1 = "/htf"
	SLASH_HAPPYTREEFRIENDS2 = "/happytreefriends"
	SlashCmdList.HAPPYTREEFRIENDS = function(input)
		HTF:HandleSlashCommand(input)
	end
end

function HTF:Initialize()
	if self.initialized then
		return
	end

	self:InitializeDatabase()
	self:RegisterSlashCommands()

	if self.Merchant then
		self.Merchant:Initialize()
	end
	if self.Stats then
		self.Stats:Initialize()
	end
	if self.Options then
		self.Options:Initialize()
	end

	self.initialized = true
	self:Debug("初始化完成。")
end

local bootstrapFrame = CreateFrame("Frame")
bootstrapFrame:RegisterEvent("ADDON_LOADED")
bootstrapFrame:SetScript("OnEvent", function(_, _, loadedAddon)
	if loadedAddon ~= ADDON_NAME then
		return
	end

	bootstrapFrame:UnregisterEvent("ADDON_LOADED")
	HTF:Initialize()
end)
